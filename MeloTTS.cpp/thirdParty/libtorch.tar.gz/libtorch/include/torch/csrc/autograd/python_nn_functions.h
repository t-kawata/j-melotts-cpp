#pragma once

namespace torch {
namespace autograd {

void initNNFunctions(PyObject* module);

}
} // namespace torch
