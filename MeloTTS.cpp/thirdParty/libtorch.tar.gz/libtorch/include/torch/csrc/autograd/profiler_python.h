#pragma once

namespace torch {
namespace autograd {
namespace profiler {
namespace python_tracer {

void init();

}
} // namespace profiler
} // namespace autograd
} // namespace torch
