#pragma once

namespace torch {
namespace autograd {

void initSparseFunctions(PyObject* module);

}
} // namespace torch
